package com.cybage;

public class Test {
	public static void main(String[] args) throws Exception{
		System.out.println("jdbc example...");
		JDBCExample je = new JDBCExample();
		je.getRecord();		
		//je.addRecord();
	}
}