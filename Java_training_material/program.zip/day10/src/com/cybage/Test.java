package com.cybage;

public class Test {
	public static void main(String[] args) throws Exception {
		System.out.println("jdbc day 2");
//		JDBCExample je = new JDBCExample();
//		je.getResultInfo();
//		je.getDbInfo();
//		je.txnMgmnt();
		ImageUsage iu = new ImageUsage();
//		iu.addImage();
		iu.getImage();
	}
}
