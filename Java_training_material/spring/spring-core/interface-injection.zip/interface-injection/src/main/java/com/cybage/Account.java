package com.cybage;

public interface Account {

}
