package com.example;

import org.springframework.stereotype.Repository;

@Repository
public interface RetiredRepository  extends EmployeeRepository{

}